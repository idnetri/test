<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Siswa_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    function insert($tablename, $data1) {
        return $this->db->insert($tablename, $data1);
    }

    function update($tablename, $kolom, $where) {
        $this->db->where($where);
        return $this->db->update($tablename, $kolom);
    }

    function get($tablename) {
        $query = $this->db->get($tablename);
        return $query->result();
    }

    function view($tablename, $data) {
        $this->db->where($data);
        $query = $this->db->get($tablename);

        return $query->result();
    }

    function view_row($tablename, $data) {
        $this->db->where($data);
        $query = $this->db->get($tablename);

        return $query->row();
    }

    function delete($tablename, $where) {
        $this->db->where($where);
        return $this->db->delete($tablename);
    }
    
}
?>

