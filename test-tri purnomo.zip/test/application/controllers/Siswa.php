<?php

defined('BASEPATH') OR exit('No direct script access allowed');
//require_once(APPPATH . 'modules/auth/controllers/Base_global.php');

class Siswa extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model(array('Siswa_m'));
        $this->load->helper('captcha');

        $this->modul = $this->uri->segment(1);
     
    }


    function index() {
        $data['p'] = 'test';
        $this->load->view('v_siswa',$data);
    }

    function tambah() {
        $data['p'] = 'test';
        $this->load->view('v_tambah_siswa',$data);
    }

    function tambahproses() {
      $post = $this->input->post();
      //print_r($post);

      $datainput = array(
        'nama'=>$post['nama'],
        'jenis_kelamin'=> $post['jenis_kelamin'],
        'hobi'=> $post['hobi'],
        'alamat'=> $post['alamat'],
        );

      $this->Siswa_m->insert('siswa',$datainput);
    }



    


}
